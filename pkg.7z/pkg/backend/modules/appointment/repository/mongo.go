package appointment_repository

import (
	internal_repository "github.com/Mateus-MS/Xeubiart.git/backend/internal/repository"
	appointment_model "github.com/Mateus-MS/Xeubiart.git/backend/modules/appointment/model"
	"go.mongodb.org/mongo-driver/mongo"
)

type AppointmentEntity = appointment_model.AppointmentEntity

type Repository struct {
	internal_repository.BaseRepository
}

func New(coll *mongo.Collection) *Repository {
	return &Repository{
		BaseRepository: internal_repository.BaseRepository{Collection: coll},
	}
}
